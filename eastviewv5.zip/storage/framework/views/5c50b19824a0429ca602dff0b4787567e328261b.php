<?php $__env->startSection('content'); ?>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php echo $__env->make('sections.dashboard.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php echo $__env->make('sections.dashboard.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <?php echo $__env->make('sections.dashboard.sub_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <!-- Content Row -->

                    <div class="row">

                        <!-- Area Chart -->
                        <div class="col-xl-8 col-lg-7">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"
                                        href="#" data-toggle="modal" data-target="#registerUser"><i
                                            class="fas fa-users fa-sm text-white-50"></i> REGISTRAR CIUDADANOS</a>
                                    <?php echo $__env->make('sections.dashboard.modal_register', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                    <div class="dropdown no-arrow">
                                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                            aria-labelledby="dropdownMenuLink">
                                            <div class="dropdown-header">Dropdown Header:</div>
                                            <a class="dropdown-item" href="#">Action</a>
                                            <a class="dropdown-item" href="#">Another action</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">Something else here</a>
                                        </div>
                                    </div>
                                </div>
                                <!-- Card Body -->
                                <?php if(count($citizens) > 0): ?>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table class="table table-bordered" id="dataTable" width="100%"
                                                cellspacing="0">
                                                <thead style="background-color: #4e73df; color:white;">
                                                    <tr>
                                                        <th style="width:25%">Nombre</th>
                                                        <th style="width:15%">Email</th>
                                                        <th>Teléfono</th>
                                                        <th><i class="fas fa-edit"></i>editar</th>
                                                        <th><i class="fas fa-trash"></i>eliminar</th>
                                                        <th>creación</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $citizens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <tr id=<?php echo e("rc_".$c->id); ?>>
                                                            <td><?php echo e($c->name); ?></td>
                                                            <td><?php echo e($c->email); ?></td>
                                                            <td><?php echo e($c->phone); ?></td>
                                                            <td><button class="btn btn-success btn-sm"><i
                                                                        class="fas fa-edit"></i></button></td>
                                                            <td><button class="btn btn-danger btn-sm" id=<?php echo e("rc".$c->id); ?> onclick='deleteCitizen(this)'><i class="fas fa-trash"></i></button></td>
                                                            <td><?php echo e($c->created_at); ?></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>
                                            </table>

                                            <?php echo $__env->make('sections.dashboard.js_delete_citizen', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                        </div>
                                        <?php echo e($citizens->links('vendor.pagination.bootstrap-4')); ?>

                                    </div>
                                    
                                <?php else: ?>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <br><br><br><br><br><br>
                                            <h5>No tiene usuarios registrados en el sistema ....</h5>
                                        </div>
                                    </div>

                            <?php endif; ?>



                        </div>
                    </div>

                    <!-- Pie Chart -->
                    <div class="col-xl-4 col-lg-3">
                        <div class="card shadow mb-4">
                            <!-- Card Header - Dropdown -->
                            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                <h6 class="m-0 font-weight-bold text-primary">Lista de tareas asignadas
                                    (<?php echo e($tasks->count()); ?>)</h6>
                                <div class="dropdown no-arrow">
                                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                    </a>

                                </div>
                            </div>
                            <!-- Card Body -->
                            <div class="card-body">
                                <?php if($tasks->count() > 0): ?>
                                    <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-warning shadow-sm"
                                        data-toggle="modal" data-target="#listTask" style="width: 50%"><i
                                            class="fas fa-project-diagram fa-sm text-white-50"></i> &nbsp; &nbsp; VER
                                        LISTA
                                        DE TAREAS <br>(eliminar o editar)</a>
                                <?php else: ?>
                                    <h6>Usted no tiene ninguna tarea registrada, puede crear una lista de tareas
                                        personalida
                                        a cada usuario</h6>
                                <?php endif; ?>
                                <?php echo $__env->make('sections.dashboard.modal_list_task', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


                                <hr>

                                <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"
                                    data-toggle="modal" data-target="#registerTask" style="width: 50%"><i
                                        class="fas fa-project-diagram fa-sm text-white-50"></i> &nbsp; &nbsp; REGISTRAR
                                    TARÉA PARA <br>CIUDADANO</a>

                                <?php echo $__env->make('sections.dashboard.modal_register_task', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>

                
                

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Full Stack Developer &copy;Jaiver Ocampo 2023</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Cerrar Sesión ?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Usted seleccionó "cerrar sesión" esta seguro ?.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="<?php echo e(url('/logout')); ?>" onclick="preload()">Cerrar Sesión</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('root.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>