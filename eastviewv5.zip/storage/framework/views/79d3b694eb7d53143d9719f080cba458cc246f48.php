<script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<?php if(session('error')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'ERROR',
            text: '<?php echo e(session('error')); ?>',
            confirmButtonText: "CERRAR"
        })
    </script>
    <?php endif; ?>
    <?php if(session('success')): ?>
    <script>
    Swal.fire({
        icon: 'success',
        title: 'INFORMACIÓN',
        text: '<?php echo e(session('success')); ?>',
        confirmButtonText: "CERRAR",
    })
    </script>
    <?php endif; ?>
