<!-- Logout Modal-->
<div class="modal fade" id="registerTask" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><b><i class="fas fa-user"></i> &nbsp; &nbsp; ASIGNAR
                        TARÉA PARA
                        CIUDADANO</b></h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="status_register_task"></div>
                <br>
                <div class="form-group row">
                    <div class="col-sm-12 mb-3 mb-sm-0">
                        <label for="">Describa la taréa</label>
                        <input type="text" class="form-control form-control-user"name="task" id="task"
                            value="esta es una tarea..." placeholder="Nombre">
                    </div>

                </div>
                <div class="form-group row">
                    <div class="col-sm-12 mb-3 mb-sm-0">
                        <label for="">Seleccione el usuario</label>
                        <select class="form-control" name="citizen_id" id="citizen_id">
                            <?php $__currentLoopData = $citizens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ci): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ci->id); ?>">
                                    <?php echo e('nombre :' . $ci->name . ',Email:' . $ci->email . ',Teléfono:' . $ci->phone); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-12 mb-3 mb-sm-0 ">
                        <?php $wi = ['Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo']; ?>
                        <label for="">Seleccione día de la semana</label>
                        <select class="form-control" name="day" id="day">
                            <option value="">Selecione día</option>
                            <?php for($i = 0; $i < sizeof($wi); $i++): ?>
                                <option value="<?php echo e($wi[$i]); ?>">
                                    <?php echo e($wi[$i]); ?>

                                </option>
                            <?php endfor; ?>
                        </select>

                    </div>
                    <hr>
                </div>
                <button type="submit" class="d-none d-sm-inline-block btn btn-sm btn-primary btn-block shadow-sm"
                    id="registeredTask">
                    <i class="fas fa-user"></i> &nbsp; &nbsp; Registrar Taréa Para el Ciudadano
                </button>

              <?php echo $__env->make('sections.dashboard.js_register_task', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" onclick="window.location.reload()">Cerrar</button>
            </div>
        </div>
    </div>
</div>
