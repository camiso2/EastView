<!-- Logout Modal-->
<div class="modal fade" id="registerUser" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><b><i class="fas fa-user"></i> &nbsp; &nbsp; REGISTRAR
                        CIUDADANO</b></h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="status_register" ></div>
                <br>
                <div class="form-group row">
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <input type="text" class="form-control form-control-user"name="name" id="name" value="andres"
                            placeholder="Nombre">
                    </div>
                    <div class="col-sm-6">
                        <input type="number" class="form-control form-control-user" name="phone" id="phone" value="3128759877" maxlength="10"
                            placeholder="Teléfono">
                    </div>
                </div>
                <div class="form-group">
                    <input type="email" class="form-control form-control-user" name="email" id="email" value="c@vwar.co"
                        placeholder="Email">
                </div>
                <button type="submit" class="d-none d-sm-inline-block btn btn-sm btn-primary btn-block shadow-sm"
                    id="registered">
                    <i class="fas fa-user"></i> &nbsp; &nbsp; Registrar Ciudadano
                </button>
                <?php echo $__env->make('sections.dashboard.js_register_user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="modal-footer">
                 <button class="btn btn-secondary" type="button" onclick="window.location.reload()" >Cerrar</button>
            </div>
        </div>
    </div>
</div>
