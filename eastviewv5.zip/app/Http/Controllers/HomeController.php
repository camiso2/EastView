<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Contracts\View\View;


use App\citizens;
use App\tasks;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       // return view('dashboard');
       $citizens = citizens::orderby('created_at','DESC')->paginate(4);
       $tasks = tasks::orderby('created_at','DESC')->get();
       $citizensTotal= citizens::all();
       return view('dashboard',compact('citizens','citizensTotal','tasks'));
    }
}
